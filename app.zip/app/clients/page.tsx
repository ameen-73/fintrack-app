"use client"

import { useState } from "react"

export default function ClientsPage() {
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [clients, setClients] = useState<any[]>([])

  function addClient() {
    if (!name) {
      alert("Please enter a client name")
      return
    }

    setClients([
      {
        id: Date.now(),
        name,
        phone,
        projects: 0,
        pending: 0,
      },
      ...clients,
    ])

    setName("")
    setPhone("")
  }

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Clients</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">👥 Clients</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">Manage your client list with a clean, unified interface.</p>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-theme-text">Add a Client</h2>
            <p className="text-theme-muted">Keep client records up to date and easy to review.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Client Name" className="input" />
            <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" className="input" />
          </div>

          <button onClick={addClient} className="button w-full md:w-auto">Add Client</button>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-4 shadow-sm">
          <h2 className="text-2xl font-bold text-theme-text">Client List</h2>
          <div className="grid gap-4">
            {clients.length === 0 ? (
              <div className="rounded-[28px] border border-theme-border bg-theme-bg p-6 text-theme-muted">No clients added yet.</div>
            ) : (
              clients.map((client) => (
                <div key={client.id} className="rounded-[28px] border border-theme-border bg-theme-bg p-6 shadow-sm hover:shadow-md transition-all duration-200">
                  <h3 className="text-xl font-bold text-theme-text">{client.name}</h3>
                  <p className="mt-2 text-theme-muted">{client.phone || "No phone provided"}</p>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </main>
  )
}
