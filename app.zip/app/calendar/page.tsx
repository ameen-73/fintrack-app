"use client"

import { useState } from "react"

export default function CalendarPage() {
  const [events] = useState([
    { id: 1, title: "Logo Delivery", date: "2026-06-10", priority: "High" },
    { id: 2, title: "Instagram Pack", date: "2026-06-15", priority: "Medium" },
  ])

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Calendar</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">📅 Calendar</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">Track deadlines and upcoming dates with a clean schedule view.</p>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-4 shadow-sm">
          <h2 className="text-2xl font-bold text-theme-text">Upcoming Events</h2>
          <div className="grid gap-4">
            {events.map((event) => (
              <div key={event.id} className="rounded-[28px] border border-theme-border bg-theme-bg p-6 shadow-sm">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-theme-text">{event.title}</h3>
                    <p className="mt-2 text-theme-muted">Due: {event.date}</p>
                  </div>
                  <span className="rounded-2xl bg-black/5 border border-theme-border px-4 py-2 text-sm text-theme-muted font-medium">Priority: {event.priority}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
