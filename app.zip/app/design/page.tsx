"use client"

export default function DesignPage() {
  const projects = [
    {
      name: "Logo Design",
      client: "ABC Company",
      progress: 75,
      amount: "₹15000",
      payment: "Pending",
    },
    {
      name: "Instagram Pack",
      client: "Brand Studio",
      progress: 100,
      amount: "₹8000",
      payment: "Paid",
    },
  ]

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Design</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">🎨 Design Workspace</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">Manage creative work with a consistent, polished interface.</p>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-theme-text">Active Design Projects</h2>
            <p className="text-theme-muted">Track progress, payments, and client work in one place.</p>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {projects.map((project) => (
              <div key={project.name} className="rounded-[28px] border border-theme-border bg-theme-bg p-6 space-y-4 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-theme-text">{project.name}</h3>
                    <p className="text-theme-muted">{project.client}</p>
                  </div>
                  <span className="rounded-2xl bg-black/5 border border-theme-border px-4 py-2 text-sm text-theme-muted font-medium">{project.payment}</span>
                </div>
                <div className="space-y-2">
                  <div className="h-3 overflow-hidden rounded-full bg-zinc-200">
                    <div className="h-3 rounded-full bg-theme-accent" style={{ width: `${project.progress}%` }} />
                  </div>
                  <p className="text-sm text-theme-muted">Progress: {project.progress}%</p>
                </div>
                <p className="text-sm text-theme-muted">Amount: {project.amount}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
