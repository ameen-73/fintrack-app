"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

const navItems = [
  { href: "/", label: "Dashboard" },
  { href: "/design", label: "Design" },
  { href: "/projects", label: "Projects" },
  { href: "/clients", label: "Clients" },
  { href: "/finance", label: "Finance" },
  { href: "/analytics", label: "Analytics" },
  { href: "/calendar", label: "Calendar" },
]

export default function TopNav() {
  const pathname = usePathname() || "/"

  return (
    <header className="sticky top-0 z-50 border-b border-theme-border bg-theme-bg/95 backdrop-blur-xl">
      <div className="mx-auto flex flex-wrap items-center justify-between gap-3 px-6 py-4 text-sm text-theme-text">
        <Link href="/" className="flex items-center gap-3 text-theme-text hover:opacity-90 transition">
          <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-theme-accent to-theme-accent-hover shadow-md shadow-theme-accent/20" />
          <div>
            <p className="font-bold tracking-tight">FinTrack</p>
            <p className="text-xs text-theme-muted">Business Workspace</p>
          </div>
        </Link>

        <nav className="flex flex-wrap items-center gap-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-2xl px-4 py-2 transition text-sm ${
                  isActive
                    ? "bg-theme-accent text-theme-card-dark font-semibold shadow-sm"
                    : "text-theme-muted hover:bg-black/5 hover:text-theme-text"
                }`}
              >
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="rounded-2xl border border-theme-border bg-black/5 px-4 py-2 text-xs text-theme-muted">
          Unified app navigation
        </div>
      </div>
    </header>
  )
}
