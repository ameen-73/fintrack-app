"use client"

import { useEffect, useState } from "react"

export default function FinancePage() {
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState("")
  const [type, setType] = useState("Income")
  const [category, setCategory] = useState("Salary")
  const [date, setDate] = useState("")
  const [records, setRecords] = useState<any[]>([])

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("finance_transactions") || "[]")
    setRecords(data)
  }, [])

  function addRecord() {
    if (!description || !amount) {
      alert("Fill fields")
      return
    }

    const newItem = {
      id: Date.now(),
      description,
      amount,
      type,
      category,
      date: date || new Date().toISOString().slice(0, 10),
      created: new Date().toISOString(),
    }

    const updated = [newItem, ...records]
    setRecords(updated)
    localStorage.setItem("finance_transactions", JSON.stringify(updated))
    setDescription("")
    setAmount("")
    setDate("")
  }

  const income = records.filter((r) => r.type === "Income").reduce((a, b) => a + Number(b.amount), 0)
  const expense = records.filter((r) => r.type === "Expense").reduce((a, b) => a + Number(b.amount), 0)

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-10">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Finance Center</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">💰 Finance Center</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">Track income, expenses, and balance with a clean financial workflow.</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Stat title="Income" value={`₹${income}`} />
          <Stat title="Expense" value={`₹${expense}`} />
          <Stat title="Balance" value={`₹${income - expense}`} highlight={true} />
        </div>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-theme-text">Add Financial Record</h2>
            <p className="text-theme-muted">Add income or expense records and keep your totals current.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="input" />
            <input value={amount} type="number" onChange={(e) => setAmount(e.target.value)} placeholder="Amount" className="input" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <select value={type} onChange={(e) => setType(e.target.value)} className="input">
              <option>Income</option>
              <option>Expense</option>
            </select>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="input">
              <option>Salary</option>
              <option>Design Payment</option>
              <option>Transport</option>
              <option>Food</option>
              <option>Bills</option>
              <option>Shopping</option>
              <option>Software</option>
              <option>Investment</option>
              <option>Other</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
            <button onClick={addRecord} className="button w-full md:w-auto">Add Financial Entry</button>
          </div>
        </section>

        <section className="space-y-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 className="text-2xl font-bold text-theme-text">Recent Entries</h2>
            <p className="text-theme-muted">Latest income and expense records appear here.</p>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {records.map((r) => (
              <div key={r.id} className="rounded-[32px] border border-theme-border bg-theme-card p-6 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-theme-text">{r.description}</h3>
                    <p className="text-theme-muted">{r.category} • {r.type}</p>
                  </div>
                  <p className={`text-2xl font-extrabold ${r.type === 'Income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {r.type === 'Income' ? '+' : '-'} ₹{r.amount}
                  </p>
                </div>
                <p className="mt-4 text-theme-muted text-sm font-medium">{r.date}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}

function Stat({ title, value, highlight }: any) {
  return (
    <div className={`rounded-[32px] p-8 shadow-sm border transition-all duration-200 ${
      highlight 
        ? 'bg-theme-card-dark text-white border-theme-border-dark shadow-md' 
        : 'bg-theme-card text-theme-text border-theme-border'
    }`}>
      <p className={`text-sm uppercase tracking-[0.25em] font-semibold ${highlight ? 'text-theme-accent' : 'text-theme-muted'}`}>{title}</p>
      <h2 className={`mt-4 text-4xl font-extrabold ${highlight ? 'text-white' : 'text-theme-text'}`}>{value}</h2>
    </div>
  )
}
