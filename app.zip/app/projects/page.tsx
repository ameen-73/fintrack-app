"use client"

import { useState } from "react"

export default function ProjectsPage() {
  const [name, setName] = useState("")
  const [client, setClient] = useState("Select Client")
  const [amount, setAmount] = useState("")
  const [deadline, setDeadline] = useState("")
  const [priority, setPriority] = useState("Medium")
  const [deliverable, setDeliverable] = useState("")
  const [preview, setPreview] = useState("")
  const [projects, setProjects] = useState<any[]>([])

  function createProject() {
    if (!name || client === "Select Client" || !amount) {
      alert("Fill all fields")
      return
    }

    setProjects([
      {
        id: Date.now(),
        name,
        client,
        amount,
        deadline,
        priority,
        deliverable,
        preview,
        invoice: `INV-${Date.now().toString().slice(-6)}`,
        received: 0,
        progress: 0,
        status: "To Do",
        paid: false,
      },
      ...projects,
    ])

    setName("")
    setClient("Select Client")
    setAmount("")
    setDeadline("")
    setPriority("Medium")
    setDeliverable("")
    setPreview("")
  }

  function receivePayment(id: number, value: number) {
    setProjects(
      projects.map((project) =>
        project.id !== id
          ? project
          : {
              ...project,
              received: Number(project.received) + value,
              paid: Number(project.received) + value >= Number(project.amount),
            }
      )
    )
  }

  function updateStatus(id: number, status: string) {
    setProjects(
      projects.map((project) =>
        project.id === id
          ? {
              ...project,
              status,
            }
          : project
      )
    )
  }

  function updateProgress(id: number, progress: number) {
    setProjects(
      projects.map((project) =>
        project.id === id ? { ...project, progress } : project
      )
    )
  }

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Projects</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">📁 Projects</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">Create projects, track progress, and manage invoicing in one place.</p>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-theme-text">New Project</h2>
            <p className="text-theme-muted">Add project details and keep your pipeline organized.</p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Project Name" className="input" />
            <select value={client} onChange={(e) => setClient(e.target.value)} className="input">
              <option>Select Client</option>
              <option>ABC Company</option>
              <option>Brand Studio</option>
              <option>Personal</option>
            </select>
            <input value={amount} type="number" onChange={(e) => setAmount(e.target.value)} placeholder="Amount" className="input" />
            <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="input" />
            <select value={priority} onChange={(e) => setPriority(e.target.value)} className="input">
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
              <option>Urgent</option>
            </select>
            <input value={deliverable} onChange={(e) => setDeliverable(e.target.value)} placeholder="Deliverables" className="input" />
            <input value={preview} onChange={(e) => setPreview(e.target.value)} placeholder="Preview Image URL" className="input" />
          </div>

          <button onClick={createProject} className="button w-full md:w-auto">Create Project</button>
        </section>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-4 shadow-sm">
          <h2 className="text-2xl font-bold text-theme-text">Project Board</h2>
          <div className="grid gap-4">
            {projects.length === 0 ? (
              <div className="rounded-[28px] border border-theme-border bg-theme-bg p-6 text-theme-muted">No projects yet.</div>
            ) : (
              projects.map((project) => (
                <div key={project.id} className="rounded-[28px] border border-theme-border bg-theme-bg p-6 space-y-4 shadow-sm hover:shadow-md transition-all duration-200">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-theme-text">{project.name}</h3>
                      <p className="text-theme-muted">Client: {project.client}</p>
                    </div>
                    <span className="rounded-2xl bg-black/5 border border-theme-border px-4 py-2 text-sm text-theme-muted font-medium">{project.status}</span>
                  </div>
                  <div className="grid gap-3 md:grid-cols-3 text-sm text-theme-muted">
                    <p className="font-semibold text-theme-text">Amount: ₹{project.amount}</p>
                    <p>Deadline: {project.deadline || "Not set"}</p>
                    <p>Priority: {project.priority}</p>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <button onClick={() => receivePayment(project.id, 1000)} className="button w-full md:w-auto">Receive ₹1000</button>
                    <div className="space-y-1">
                      <p className="text-sm text-theme-muted font-medium">Progress: {project.progress}%</p>
                      <input type="range" min="0" max="100" value={project.progress} onChange={(e) => updateProgress(project.id, Number(e.target.value))} className="w-full accent-theme-accent" />
                    </div>
                  </div>
                  <select value={project.status} onChange={(e) => updateStatus(project.id, e.target.value)} className="input">
                    <option>To Do</option>
                    <option>Working</option>
                    <option>Revision</option>
                    <option>Delivered</option>
                  </select>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </main>
  )
}
