"use client"

import { useEffect, useState } from "react"

function Stat({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-[32px] border border-theme-border bg-theme-card p-8 shadow-sm">
      <p className="text-sm uppercase tracking-[0.25em] text-theme-muted font-medium">{title}</p>
      <h2 className="mt-4 text-4xl font-extrabold text-theme-text">{value}</h2>
    </div>
  )
}

function Card({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-[28px] border border-theme-border bg-theme-bg p-6 shadow-sm">
      <p className="text-sm uppercase tracking-[0.3em] text-theme-muted font-medium">{title}</p>
      <p className="mt-3 text-2xl font-bold text-theme-text">{value}</p>
    </div>
  )
}

export default function AnalyticsPage() {
  const [finance, setFinance] = useState<any[]>([])

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("finance_transactions") || "[]")
    setFinance(data)
  }, [])

  const total = finance.reduce((sum, item) => sum + Number(String(item.amount).replace(/[^0-9]/g, "")), 0)

  return (
    <main className="min-h-screen bg-theme-bg text-theme-text p-6 sm:p-8">
      <div className="max-w-[1200px] mx-auto space-y-8">
        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 shadow-sm">
          <p className="text-sm uppercase tracking-[0.3em] text-theme-accent font-semibold">Analytics</p>
          <h1 className="mt-4 text-5xl font-extrabold text-theme-text">📊 Analytics</h1>
          <p className="mt-3 max-w-2xl text-theme-muted">See totals, transactions, and revenue at a glance.</p>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          <Stat title="Revenue" value={`₹${total}`} />
          <Stat title="Transactions" value={`${finance.length}`} />
          <Stat title="Pending" value="₹0" />
          <Stat title="Completion" value="75%" />
        </div>

        <section className="rounded-[32px] border border-theme-border bg-theme-panel p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-theme-text">Recent Payments</h2>
            <p className="text-theme-muted">A quick list of the latest financial activity.</p>
          </div>

          <div className="grid gap-4">
            {finance.length === 0 ? (
              <div className="rounded-[28px] border border-theme-border bg-theme-bg p-6 text-theme-muted">No payments recorded yet.</div>
            ) : (
              finance.map((item) => (
                <Card key={item.id} title={item.name || "Payment"} value={item.amount || "₹0"} />
              ))
            )}
          </div>
        </section>
      </div>
    </main>
  )
}
